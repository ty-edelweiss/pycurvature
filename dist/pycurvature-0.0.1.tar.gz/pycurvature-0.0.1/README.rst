A PyCurvature Python project
=======================

This project aim to estimate curvature of the observed value. This makes it possible to estimate curvature by cricle regression model.

----

This is the README file for the project.

set wrapper for the following modules

pandas
